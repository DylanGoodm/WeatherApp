package com.example.weatherapphw3;

public class Coord {
}
