package com.example.weatherapphw3;

import java.util.ArrayList;

public class CurrentWeatherResponse {
    Coord coord;
    ArrayList<Weather> weather;
    String base;
    Main main;
    int visibility;
    Wind wind;
    Clouds clouds;
    int dt;
    Sys sys;
    int timezone;
    int id;
    String name;
    String cod;
}
